# ASK UNION Android APK

Native Android WebView wrapper for the ASK UNION PWA.

Website:
https://sbisajaipur.github.io/Ask-union-jaipur/

The included GitHub Actions workflow builds a debug APK and uploads it as an artifact.
